import hashlib, json, os, pathlib, shlex, subprocess, time
root=pathlib.Path('/probe'); tool=root/'mold-2.42.1-aarch64-linux/bin/mold'
rows=[]
def run(name,args,cwd=root):
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as log:
  result=subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':args,'cwd':str(cwd),'returncode':result.returncode,'elapsed_seconds':time.monotonic()-start}
 rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 return result.returncode==0
run('local-reloc',[str(tool),'--emit-relocs','-o','local-reloc','/work/probe/local-reloc.o'])
text=subprocess.check_output(['readelf','-rW',str(root/'local-reloc')],text=True)
(root/'local-reloc-readelf.log').write_text(text);assert 'str + 0' in text and '_start' not in text
for args in json.loads((root/'m2-commands.json').read_text()):
 name=pathlib.Path(args[args.index('-o')+1]).name
 if run(name+'-link',args,pathlib.Path('/experiment/cpp/M2-bfd')):
  run(name+'-run',[str(root/name)])
cmd=subprocess.check_output(['uvx','--from','ninja==1.13.0','ninja','-C','/work/fat-build','-t','commands','bin/mlir-tblgen'],text=True).splitlines()[-1]
args=shlex.split(cmd.removeprefix(': && ').removesuffix(' && :'))
args=[s for s in args if not s.startswith('-Wl,--dependency-file=')]
args=[s.replace('-fuse-ld=bfd','-fuse-ld=mold').replace('-fno-lto','-flto=4') for s in args]
args.insert(1,'-B/probe/mold-2.42.1-aarch64-linux/bin');args.append('-Wl,--emit-relocs')
args[args.index('-o')+1]='/probe/mlir-tblgen'
if run('tblgen-link',args,pathlib.Path('/work/fat-build')):
 run('tblgen-relocs',['readelf','-rW','/probe/mlir-tblgen'])
 run('tblgen-run',['/probe/mlir-tblgen','--version'])
 os.environ['PATH']='/work/native-sdk/bin:'+os.environ['PATH']
 run('tblgen-bolt',['/work/native-sdk/bin/mqt-bolt-optimize','/probe/mlir-tblgen','--','/probe/mlir-tblgen','--help'])
print('Completed',flush=True)
