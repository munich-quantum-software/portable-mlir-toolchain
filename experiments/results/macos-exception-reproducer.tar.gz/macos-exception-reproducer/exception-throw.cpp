#include <stdexcept>
void marker() { throw std::out_of_range("known diagnostic marker"); }
