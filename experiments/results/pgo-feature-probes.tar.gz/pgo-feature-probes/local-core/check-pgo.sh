set -euxo pipefail
/opt/clang/bin/clang++ --version
cat /opt/clang/bin/*.cfg
/opt/clang/bin/clang++ -O3 -fPIC -flto=full -fprofile-use=current.profdata -c runtime.cpp -o runtime.o
/opt/clang/bin/llvm-ar cr runtime.a runtime.o
/opt/clang/bin/clang++ -O3 -fPIC -flto=full -fprofile-use=current.profdata -c device.cpp -o device.o
/opt/clang/bin/clang++ -fPIC -flto=full -fprofile-use=current.profdata -shared -fuse-ld=lld -Wl,--thinlto-jobs=1,--lto-partitions=1,--no-relax,--build-id=sha1 -Wl,-z,defs -Wl,-z,nodelete -Wl,--emit-relocs,--exclude-libs,ALL,--gc-sections device.o runtime.a -o device.so
/opt/python/cp311-cp311/bin/python -c 'import ctypes; d=ctypes.CDLL("./device.so"); assert d.entry()==1; assert d.entry()==2'
