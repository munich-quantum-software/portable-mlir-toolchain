"""Reproduce PGO contamination of CMake feature checks with a small profile."""
from pathlib import Path
import ctypes
import json
import os
import subprocess
import sys
import threading

compiler, profdata = map(Path, sys.argv[1:3])
output = Path(sys.argv[3]).resolve()
output.mkdir(parents=True)
source = Path(__file__).resolve().parent
records = []

def run(label, command, *, succeeds=True, env=None):
    result = subprocess.run(list(map(str, command)), env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / (label + ".log")).write_text(result.stdout)
    records.append({"label": label, "command": list(map(str, command)), "returncode": result.returncode})
    assert (result.returncode == 0) == succeeds, result.stdout
    return result.stdout

run("instrument", [compiler, "-O3", "-flto=full", "-fprofile-generate", "-fuse-ld=lld", source / "train.cpp", "-o", output / "train"])
run("train", [output / "train"], env=os.environ | {"LLVM_PROFILE_FILE": str(output / "main.profraw")})
run("merge", [profdata, "merge", output / "main.profraw", "-o", output / "main.profdata"])
flags = f"-flto=full -fprofile-use={output / 'main.profdata'}"
for label in ["before", "after"]:
    config = output / (label + ".cmake")
    lines = [f'set(CMAKE_CXX_COMPILER "{compiler}" CACHE FILEPATH "" FORCE)', 'set(CMAKE_LINKER_TYPE LLD CACHE STRING "" FORCE)']
    if label == "before":
        lines.append(f'set(CMAKE_CXX_FLAGS "{flags}" CACHE STRING "" FORCE)')
    else:
        lines.extend([f'add_compile_options({flags})', f'add_link_options({flags})'])
    config.write_text("\n".join(lines) + "\n")
    log = run(label, ["cmake", "-S", source, "-B", output / label, f"-DCMAKE_PROJECT_INCLUDE_BEFORE={config}"], succeeds=label == "after")
    assert ("PROFILE_FREE_FPIC - Success" if label == "after" else "PROFILE_FREE_FPIC - Failed") in log
run("build", ["cmake", "--build", output / "after", "-j", "2"])
lib = ctypes.CDLL(str(output / "after/libdevice.so"))
assert lib.entry() == 1 and lib.entry() == 2
values = []
thread = threading.Thread(target=lambda: values.append(lib.entry()))
thread.start()
thread.join()
assert values == [1] and lib.entry() == 3
(output / "results.json").write_text(json.dumps({"commands": records, "thread_local_check": True}, indent=2) + "\n")
print("Profile-free compiler probes and PGO shared-library TLS passed:", output)
