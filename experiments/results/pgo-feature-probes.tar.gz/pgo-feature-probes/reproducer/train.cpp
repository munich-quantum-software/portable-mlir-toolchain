int main(int argc, char**) { volatile int total = 0; for (int i = 0; i < argc + 4; ++i) total = total + i; return total < 0; }
