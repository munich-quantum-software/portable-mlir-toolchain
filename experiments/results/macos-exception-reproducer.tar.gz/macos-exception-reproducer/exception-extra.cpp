#include <exception>
void check(void (*call)()) {
  try { call(); } catch (const std::exception&) {}
}
