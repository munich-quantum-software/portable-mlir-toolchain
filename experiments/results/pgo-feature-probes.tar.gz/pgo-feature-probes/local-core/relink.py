import json,subprocess
from pathlib import Path
build=Path('/tmp/mqt-core-tls/build/final')
commands=subprocess.check_output(['uvx','--from','ninja==1.13.0','ninja','-C',str(build),'-t','commands','mqt-core-qdmi-ddsim-device'],text=True).splitlines()
links=[c for c in commands if ' -o lib64/libmqt-core-qdmi-ddsim-device.so ' in c]
assert len(links)==1
original=links[0]
Path('/tmp/mqt-tls-diagnostic/link-command.txt').write_text(original+'\n')
command=original.replace(' -shared ',' -shared -Wl,--save-temps ')
with open('/tmp/mqt-tls-diagnostic/relink-save.log','w') as log:
 result=subprocess.run(command,shell=True,cwd=build,stdout=log,stderr=subprocess.STDOUT)
print('saved LTO diagnostic link return code:',result.returncode)
