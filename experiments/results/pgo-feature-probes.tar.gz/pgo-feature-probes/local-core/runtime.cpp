namespace { thread_local int *active = nullptr; }
int &runtime() { static thread_local int fallback = 0; return active ? *active : fallback; }
