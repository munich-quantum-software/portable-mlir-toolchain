# PGO compiler-probe regression

Run on Linux with Clang, its matching profiling runtime and `llvm-profdata`,
and CMake 3.28 or newer on `PATH`:

```sh
python3 run.py /opt/clang/bin/clang++ /path/to/llvm-profdata /tmp/new-pgo-probe-results
```

The output directory must not exist. The old configuration must fail its PIC
feature check because an unrelated trained `main` triggers a profile-mismatch
warning under `-Werror`. The corrected configuration must pass that check,
build the PGO shared library, and preserve independent thread-local state.
The full Core failure and corrected wheel build are retained separately.
