set(CMAKE_CXX_COMPILER "/opt/clang/bin/clang++" CACHE FILEPATH "" FORCE)
set(CMAKE_LINKER_TYPE LLD CACHE STRING "" FORCE)
add_compile_options(-flto=full -fprofile-use=/tmp/pgo-probe-results/main.profdata)
add_link_options(-flto=full -fprofile-use=/tmp/pgo-probe-results/main.profdata)
