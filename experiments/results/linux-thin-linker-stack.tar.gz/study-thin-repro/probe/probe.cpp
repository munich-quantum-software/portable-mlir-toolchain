#include <llvm/Passes/PassBuilder.h>
#include <llvm/Support/TargetSelect.h>
extern "C" int probe() {
  llvm::InitializeNativeTarget();
  llvm::PassBuilder builder;
  return 0;
}
