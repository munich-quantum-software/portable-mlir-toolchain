#include <cstdio>
#include <exception>
#include <stdexcept>
static void report(const std::exception_ptr& exception) {
  try { std::rethrow_exception(exception); }
  catch (const std::exception& error) { std::printf("standard exception: %s\n", error.what()); }
  catch (...) { std::puts("unknown exception"); }
}
void marker();
int main() {
  try { marker(); }
  catch (...) { report(std::current_exception()); }
}
