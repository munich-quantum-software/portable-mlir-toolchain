set(CMAKE_CXX_COMPILER "/opt/clang/bin/clang++" CACHE FILEPATH "" FORCE)
set(CMAKE_LINKER_TYPE LLD CACHE STRING "" FORCE)
set(CMAKE_CXX_FLAGS "-flto=full -fprofile-use=/tmp/pgo-probe-results/main.profdata" CACHE STRING "" FORCE)
