set -euxo pipefail
export DEPLOY=ON CC=/opt/clang/bin/clang CXX=/opt/clang/bin/clang++
export AR=/opt/clang/bin/llvm-ar RANLIB=/opt/clang/bin/llvm-ranlib
export CMAKE_BUILD_PARALLEL_LEVEL=4 SCCACHE_GHA_ENABLED=false
export PATH=/opt/clang/bin:$PATH
uv build /tmp/mqt-core-tls --wheel --python /opt/python/cp315-cp315t/bin/python --out-dir /tmp/mqt-core-tls/wheelhouse -Cbuild-dir=/tmp/mqt-core-tls/build/fixed -Cinstall.strip=false -Ccmake.define.CMAKE_PROJECT_INCLUDE_BEFORE=/tmp/mqt-tls-diagnostic/release-fixed.cmake
