#!/usr/bin/env bash
# Copyright (c) 2023 - 2026 Chair for Design Automation, TUM
# Copyright (c) 2025 - 2026 Munich Quantum Software Company GmbH
# All rights reserved.
#
# SPDX-License-Identifier: MIT
#
# Licensed under the MIT License

set -euo pipefail

project=$(cd "$(dirname "$0")/.." && pwd)
core="$project/core"
cd "$core"
: "${STUDY_ROOT:?}" "${STUDY_OPERATION:?}" "${STUDY_SDK_LTO:?}"
mkdir -p "$STUDY_ROOT/source" "$STUDY_ROOT/input-sdk"
if [[ $(uname -s) == Linux ]]; then
  yum install -y time
  /opt/python/cp314-cp314/bin/python3 -m pip install uv==0.12.5
  export PATH="/opt/python/cp314-cp314/bin:$PATH"
  manylinux-install-clang -v 22.1.8.1 -c 8b399744aeb49c70048b379b9b3ffc651d86fde808551c8cc4138c4fadc5308e
  mkdir -p "$STUDY_ROOT/output/measurements"
  python3 "$project/experiments/configure_linker_stack.py" /opt/clang/bin/lld \
    > "$STUDY_ROOT/output/measurements/linker-stack.json"
  export CC=/opt/clang/bin/clang CXX=/opt/clang/bin/clang++
  export AR=/opt/clang/bin/llvm-ar RANLIB=/opt/clang/bin/llvm-ranlib
  export LLVM_PROFDATA=/opt/clang/bin/llvm-profdata
  export PATH="/opt/clang/bin:$PATH"
  git config --global --add safe.directory "$project"
  git config --global --add safe.directory "$core"
else
  export CC CXX AR RANLIB LLVM_PROFDATA SDKROOT
  CC=$(xcrun --find clang)
  CXX=$(xcrun --find clang++)
  AR=$(xcrun --find ar)
  RANLIB=$(xcrun --find ranlib)
  LLVM_PROFDATA=$(xcrun --find llvm-profdata)
  SDKROOT=$(xcrun --show-sdk-path)
  xcodebuild -version > "$STUDY_ROOT/xcode.txt"
  xcrun --show-sdk-build-version >> "$STUDY_ROOT/xcode.txt"
fi

uv venv --python 3.14.7 "$STUDY_ROOT/venv"
if [[ "$STUDY_OPERATION" == sdk ]]; then
  uv pip install --python "$STUDY_ROOT/venv/bin/python" cmake==4.4.3 ninja==1.13.0
else
  uv export --frozen --no-default-groups --group build --group test-base --no-emit-project --no-hashes > "$STUDY_ROOT/build-requirements.txt"
  uv pip sync --python "$STUDY_ROOT/venv/bin/python" "$STUDY_ROOT/build-requirements.txt"
  uv pip install --python "$STUDY_ROOT/venv/bin/python" wheel==0.45.1 ninja==1.13.0 "delocate==0.13.0; sys_platform == 'darwin'"
fi
export PATH="$STUDY_ROOT/venv/bin:$PATH"
set --
if [[ ${STUDY_WARM_CACHE:-false} == true ]]; then
  uv pip install --python "$STUDY_ROOT/venv/bin/python" sccache==0.16.0
  set -- --warm-cache
fi

if [[ $(uname -s) == Linux && ${STUDY_PGO:-none} != none ]]; then
  python "$project/experiments/linux_optimization.py" --output "$STUDY_ROOT/output/measurements/provision-profile.json" -- \
    bash "$project/scripts/toolchain/linux/install-profile-tools.sh" "$STUDY_ROOT/profiling"
  export LLVM_PROFDATA="$STUDY_ROOT/profiling/tools/bin/llvm-profdata"
  cp "$STUDY_ROOT/profiling/source.sha256" "$STUDY_ROOT/output/measurements/profile-source.sha256"
  cp "$STUDY_ROOT/profiling/tools.sha256" "$STUDY_ROOT/output/measurements/profile-tools.sha256"
fi

llvm_commit=ea7d852a70e8bdfaf601d6626a760f9771b2c4b4
curl --fail --location --retry 3 "https://github.com/llvm/llvm-project/archive/$llvm_commit.tar.gz" -o "$STUDY_ROOT/source.tar.gz"
tar -xf "$STUDY_ROOT/source.tar.gz" -C "$STUDY_ROOT/source" --strip-components=1
python -c 'import hashlib,sys; print(hashlib.file_digest(open(sys.argv[1], "rb"), "sha256").hexdigest())' "$STUDY_ROOT/source.tar.gz" > "$STUDY_ROOT/source.sha256"
rm "$STUDY_ROOT/source.tar.gz"
archive=$(find "$STUDY_ROOT/download" -name '*.tar.zst' -print -quit)
test -n "$archive"
python3 "$project/experiments/extract_study_sdk.py" "$archive" "$STUDY_ROOT/input-sdk"

python "$project/experiments/optimization_study.py" "$STUDY_OPERATION" --core "$core" \
  --root "$STUDY_ROOT/output" --sdk "$STUDY_ROOT/input-sdk" \
  --llvm-source "$STUDY_ROOT/source" --llvm-source-id "$llvm_commit" \
  --sdk-lto "$STUDY_SDK_LTO" \
  --core-lto "${STUDY_CORE_LTO:-OFF}" --pgo "${STUDY_PGO:-none}" \
  --jobs "${STUDY_JOBS:-4}" --lto-workers "${STUDY_LTO_WORKERS:-1}" "$@"
