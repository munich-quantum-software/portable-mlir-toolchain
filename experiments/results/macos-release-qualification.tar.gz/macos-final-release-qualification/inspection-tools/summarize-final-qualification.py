from datetime import datetime
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
core = Path('/home/nvidia/.codex/worktrees/core-release-integration')
revision = '1691559de4868923dacc3e565c7c00130d437773'
sdk_costs = {r['platform']: r['complete_fresh_pipeline_job_seconds'] for r in json.loads((root.parent / 'experiments/results/native-sdk-release-qualification.json').read_text())['records']}
jobs = [
    ('linux', 'linux-x64', 'x86_64', 'cp315t', 34721263840, 103627453676),
    ('linux', 'linux-arm64', 'aarch64', 'cp311', 34721263840, 103627453812),
    ('linux', 'linux-arm64', 'aarch64', 'cp315t', 34721263840, 103627453886),
    ('linux', 'linux-x64', 'x86_64', 'cp311', 34721263840, 103627453930),
    ('macos', 'macos-arm64', 'macos', 'cp311', 34721264654, 103627458067),
    ('macos', 'macos-arm64', 'macos', 'cp315t', 34721264654, 103627458308),
]
rows = []
for system, platform, arch, abi, run, job_id in jobs:
    artifact = root / f'release-{system}-final-qualification' / f'release-validation-{arch}-{abi}'
    wheels = list(artifact.rglob('*.whl'))
    if not wheels:
        continue
    assert len(wheels) == 1
    wheel = wheels[0]
    job_file = root / f'release-final-job-{job_id}.json'
    if not job_file.exists():
        job_file.write_bytes(subprocess.check_output(['gh', 'api', f'repos/munich-quantum-software/portable-mlir-toolchain/actions/jobs/{job_id}']))
    job = json.loads(job_file.read_text())
    assert job['conclusion'] == 'success', job
    read = lambda name: json.loads(next(artifact.rglob(name)).read_text())
    pipeline, identity, commands = read('pipeline.json'), read('identity.json'), read('commands.json')
    assert pipeline['returncode'] == 0
    assert {s['stage'] for s in commands} == {'core-generate', 'sdk-generate', 'core-generate-sdk', 'unpack', 'train', 'merge', 'sdk-use'}
    assert all(s['returncode'] == 0 for s in commands)
    variant = read('variant-use.json')
    assert variant['returncode'] == 0 and variant['assertions'] is False and variant['lto'] == 'OFF'
    assert variant['profile_sha256'] == identity['profile_sha256']
    profile = next(artifact.rglob('*.profdata'))
    assert hashlib.sha256(profile.read_bytes()).hexdigest() == profile.stem == identity['profile_sha256']
    assert identity['llvm_source_id'] == '6dfe1677ab8dffbc6ec13d53a1e0215d75147689'
    assert identity['pgo'] == 'both' and identity['sdk_lto'] == 'OFF'
    assert identity['core_lto'] == ('Full' if system == 'linux' else 'Thin')
    for name, digest in identity['training_sha256'].items():
        assert hashlib.sha256((core / 'test/release' / name).read_bytes()).hexdigest() == digest
    cache_file = next(p for p in artifact.rglob('CMakeCache.txt') if p.as_posix().endswith('/build/python/Release/CMakeCache.txt'))
    cache = cache_file.read_text()
    assert 'C_SUPPORTS_FPIC:INTERNAL=1' in cache and 'CXX_SUPPORTS_FPIC:INTERNAL=1' in cache
    config = next(artifact.rglob('release-pgo.cmake')).read_text()
    assert 'add_compile_options(-flto=' in config and 'add_link_options(-flto=' in config
    assert 'set(CMAKE_CXX_FLAGS' not in config and 'set(CMAKE_C_FLAGS' not in config
    with zipfile.ZipFile(wheel) as z:
        metadata = z.read(next(n for n in z.namelist() if n.endswith('.dist-info/WHEEL'))).decode()
    assert 'g1691559de' in wheel.name
    job_seconds = (datetime.fromisoformat(job['completed_at']) - datetime.fromisoformat(job['started_at'])).total_seconds()
    assert job_seconds < 300 * 60
    row = dict(platform=platform, abi=abi, workflow_run=run, job_id=job_id, core_revision=revision, sdk_run=34697289386, conclusion=job['conclusion'], wheel=wheel.name, wheel_bytes=wheel.stat().st_size, wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(), wheel_metadata=metadata, job_seconds=job_seconds, cibuildwheel_seconds=pipeline['elapsed_seconds'], sdk_plus_wheel_summed_job_work_seconds=sdk_costs[platform] + job_seconds, sdk_profile_archive_count=len(read('pgo-targets.json')), identity=identity, stages_seconds={s['stage']:s['seconds'] for s in commands}, final_pic_probes_passed=True)
    if system == 'linux':
        params = pipeline['container_parameters']
        assert params['nano_cpus'] == 4_000_000_000 and params['memory'] == params['memory_swap'] == 16 * 1024**3
        assert pipeline['sampled_swap_bytes'] == 0
        row.update(cgroup_peak_bytes=pipeline['cgroup_peak_bytes'], sampled_swap_bytes=0, container_parameters=params, memory_scope='Container cgroup including filesystem cache; not Docker-wrapper RSS.')
    else:
        assert 'CMAKE_OSX_DEPLOYMENT_TARGET:STRING=13.3' in cache
        assert '-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0' in variant['configure']
        row.update(core_deployment_target='13.3', sdk_deployment_target='11.0')
        row.update(cibuildwheel_sampled_tree_rss_bytes=pipeline['sampled_tree_rss_bytes'], swap_measured=False, memory_scope='Sampled process-tree RSS covers cibuildwheel; supplementary C++/consumer checks are outside that scope.')
    log = next(artifact.rglob('pipeline.log')).read_text()
    job_log = root / f'release-final-job-{job_id}.log'
    if job_log.exists():
        log += '\n' + job_log.read_text()
    log = re.sub(r'\x1b\[[0-9;]*m', '', log)
    row['python_test_summary_lines'] = sorted(set(line.strip() for line in log.splitlines() if re.search(r'\b\d+ passed\b', line) and ('===' in line or 'skipped' in line)))
    row['cpp_ctest_totals_listed'] = sorted({int(n) for n in re.findall(r'100% tests passed out of (\d+)', log)})
    row['cpp_skipped_test_names'] = sorted(set(re.findall(r'\d+ - ([^\n]+?) \(Skipped\)', log)))
    row['bolt_nonempty_profile_records'] = sorted(set(re.findall(r'BOLT-INFO: .*have non-empty execution profile', log)))
    if abi == 'cp311':
        assert row['cpp_ctest_totals_listed'] == [3545]
        assert row['python_test_summary_lines']
    rows.append(row)
    (root / f'release-final-summary-{platform}-{abi}.json').write_text(json.dumps(row, indent=2) + '\n')
    print(platform, abi, round(job_seconds / 60, 2), 'min;', wheel.stat().st_size, 'wheel bytes;', row['sdk_profile_archive_count'], 'SDK archives')
(root / 'release-final-qualification-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
if '--complete' in sys.argv:
    assert len(rows) == len(jobs), (len(rows), len(jobs))
print(len(rows), 'of', len(jobs), 'final artifacts summarized')
