.text
.globl _start
_start:
  .reloc _start, BFD_RELOC_64, str
  .space 8
.data
str:
  .string "Hello"
