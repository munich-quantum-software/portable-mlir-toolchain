from pathlib import Path
import hashlib
import json
import re
import subprocess
import tempfile
import zipfile

root = Path(__file__).resolve().parent
reader = Path('/home/nvidia/.local/opt/mqt-llvm-mlir/23.1.0/bin/llvm-objdump')
for abi in ('cp311', 'cp315t'):
    wheels = list((root / 'release-macos-final-qualification' / f'release-validation-macos-{abi}').rglob('*.whl'))
    if not wheels:
        continue
    assert len(wheels) == 1
    wheel = wheels[0]
    output = root / 'release-macos-final-inspection' / abi
    output.mkdir(parents=True, exist_ok=True)
    records = []
    with zipfile.ZipFile(wheel) as archive, tempfile.TemporaryDirectory() as tmp:
        for item in archive.infolist():
            if item.is_dir():
                continue
            with archive.open(item) as stream:
                if stream.read(4) != b'\xcf\xfa\xed\xfe':
                    continue
            data = archive.read(item)
            binary = Path(tmp) / Path(item.filename).name
            binary.write_bytes(data)
            command = [str(reader), '--macho', '--private-headers', '--dylibs-used', '--rpaths', str(binary)]
            result = subprocess.run(command, check=True, text=True, capture_output=True)
            log = result.stdout + result.stderr
            assert re.search(r'MH_MAGIC_64\s+ARM64\s+', log), item.filename
            versions = re.findall(r'^\s*minos\s+(\S+)', log, re.MULTILINE)
            assert versions and set(versions) == {'13.3'}, (item.filename, versions)
            dependencies = re.findall(r'^\s+(\S+) \(compatibility version', log, re.MULTILINE)
            assert dependencies and all(d.startswith(('@loader_path/', '@rpath/', '/usr/lib/', '/System/Library/')) for d in dependencies), dependencies
            rpaths = re.findall(r'cmd LC_RPATH\s+cmdsize \d+\s+path (.*?) \(offset', log)
            assert all(p.startswith(('@loader_path', '@executable_path', '@rpath')) for p in rpaths), rpaths
            if item.filename.endswith('.so'):
                assert 'TWOLEVEL' in log, item.filename
            name = item.filename.replace('/', '__') + '.log'
            (output / name).write_text(log)
            records.append(dict(path=item.filename, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), minimum_os_versions=versions, dependencies=dependencies, rpaths=rpaths, command=command, log=name))
            binary.unlink()
    assert len(records) == 13
    summary = dict(wheel=wheel.name, wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(), objdump=str(reader), objdump_sha256=hashlib.sha256(reader.read_bytes()).hexdigest(), records=records)
    (output / 'records.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(abi, '13 ARM64 Mach-O files require macOS 13.3 and have no build-directory dependencies or runtime paths')
