static int value() { return 42; }
static int (*volatile callback)() = value;
extern "C" __attribute__((visibility("default"))) int PyInit_dd() { return callback(); }
