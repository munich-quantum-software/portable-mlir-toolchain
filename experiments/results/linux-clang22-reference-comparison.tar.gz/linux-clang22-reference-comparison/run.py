from pathlib import Path
import json, subprocess, sys
root=Path(__file__).resolve().parent
variants=json.loads((root/'variants.json').read_text())
for cohort in [1,2]:
    command=[sys.executable, str(root.parents[1]/'experiments/evaluate_optimization.py'), str(root/f'cohort-{cohort}'), *variants, '--core', '/home/nvidia/.codex/worktrees/linux-optimization-experiments', '--cpu', '19', '--reference', 'M-PGO-native-clang-bench-both-bolt']
    (root/f'cohort-{cohort}'/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    subprocess.run(command,check=True)
