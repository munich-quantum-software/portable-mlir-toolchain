int &runtime();
extern "C" int entry() { return ++runtime(); }
