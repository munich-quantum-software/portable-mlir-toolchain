set(CMAKE_CXX_COMPILER "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/clang-manylinux/clang++")
set(CMAKE_CXX_COMPILER_ARG1 "")
set(CMAKE_CXX_COMPILER_ID "Clang")
set(CMAKE_CXX_COMPILER_VERSION "23.1.0")
set(CMAKE_CXX_COMPILER_VERSION_INTERNAL "")
set(CMAKE_CXX_COMPILER_WRAPPER "")
set(CMAKE_CXX_STANDARD_COMPUTED_DEFAULT "17")
set(CMAKE_CXX_EXTENSIONS_COMPUTED_DEFAULT "ON")
set(CMAKE_CXX_STANDARD_LATEST "26")
set(CMAKE_CXX_COMPILE_FEATURES "cxx_std_98;cxx_template_template_parameters;cxx_std_11;cxx_alias_templates;cxx_alignas;cxx_alignof;cxx_attributes;cxx_auto_type;cxx_constexpr;cxx_decltype;cxx_decltype_incomplete_return_types;cxx_default_function_template_args;cxx_defaulted_functions;cxx_defaulted_move_initializers;cxx_delegating_constructors;cxx_deleted_functions;cxx_enum_forward_declarations;cxx_explicit_conversions;cxx_extended_friend_declarations;cxx_extern_templates;cxx_final;cxx_func_identifier;cxx_generalized_initializers;cxx_inheriting_constructors;cxx_inline_namespaces;cxx_lambdas;cxx_local_type_template_args;cxx_long_long_type;cxx_noexcept;cxx_nonstatic_member_init;cxx_nullptr;cxx_override;cxx_range_for;cxx_raw_string_literals;cxx_reference_qualified_functions;cxx_right_angle_brackets;cxx_rvalue_references;cxx_sizeof_member;cxx_static_assert;cxx_strong_enums;cxx_thread_local;cxx_trailing_return_types;cxx_unicode_literals;cxx_uniform_initialization;cxx_unrestricted_unions;cxx_user_literals;cxx_variadic_macros;cxx_variadic_templates;cxx_std_14;cxx_aggregate_default_initializers;cxx_attribute_deprecated;cxx_binary_literals;cxx_contextual_conversions;cxx_decltype_auto;cxx_digit_separators;cxx_generic_lambdas;cxx_lambda_init_captures;cxx_relaxed_constexpr;cxx_return_type_deduction;cxx_variable_templates;cxx_std_17;cxx_std_20;cxx_std_23;cxx_std_26")
set(CMAKE_CXX98_COMPILE_FEATURES "cxx_std_98;cxx_template_template_parameters")
set(CMAKE_CXX11_COMPILE_FEATURES "cxx_std_11;cxx_alias_templates;cxx_alignas;cxx_alignof;cxx_attributes;cxx_auto_type;cxx_constexpr;cxx_decltype;cxx_decltype_incomplete_return_types;cxx_default_function_template_args;cxx_defaulted_functions;cxx_defaulted_move_initializers;cxx_delegating_constructors;cxx_deleted_functions;cxx_enum_forward_declarations;cxx_explicit_conversions;cxx_extended_friend_declarations;cxx_extern_templates;cxx_final;cxx_func_identifier;cxx_generalized_initializers;cxx_inheriting_constructors;cxx_inline_namespaces;cxx_lambdas;cxx_local_type_template_args;cxx_long_long_type;cxx_noexcept;cxx_nonstatic_member_init;cxx_nullptr;cxx_override;cxx_range_for;cxx_raw_string_literals;cxx_reference_qualified_functions;cxx_right_angle_brackets;cxx_rvalue_references;cxx_sizeof_member;cxx_static_assert;cxx_strong_enums;cxx_thread_local;cxx_trailing_return_types;cxx_unicode_literals;cxx_uniform_initialization;cxx_unrestricted_unions;cxx_user_literals;cxx_variadic_macros;cxx_variadic_templates")
set(CMAKE_CXX14_COMPILE_FEATURES "cxx_std_14;cxx_aggregate_default_initializers;cxx_attribute_deprecated;cxx_binary_literals;cxx_contextual_conversions;cxx_decltype_auto;cxx_digit_separators;cxx_generic_lambdas;cxx_lambda_init_captures;cxx_relaxed_constexpr;cxx_return_type_deduction;cxx_variable_templates")
set(CMAKE_CXX17_COMPILE_FEATURES "cxx_std_17")
set(CMAKE_CXX20_COMPILE_FEATURES "cxx_std_20")
set(CMAKE_CXX23_COMPILE_FEATURES "cxx_std_23")
set(CMAKE_CXX26_COMPILE_FEATURES "cxx_std_26")

set(CMAKE_CXX_PLATFORM_ID "Linux")
set(CMAKE_CXX_SIMULATE_ID "")
set(CMAKE_CXX_COMPILER_FRONTEND_VARIANT "GNU")
set(CMAKE_CXX_COMPILER_APPLE_SYSROOT "")
set(CMAKE_CXX_SIMULATE_VERSION "")
set(CMAKE_CXX_COMPILER_ARCHITECTURE_ID "aarch64")




set(CMAKE_AR "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/bin/llvm-ar")
set(CMAKE_CXX_COMPILER_AR "/usr/bin/llvm-ar-23")
set(CMAKE_RANLIB "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/bin/llvm-ranlib")
set(CMAKE_CXX_COMPILER_RANLIB "/usr/bin/llvm-ranlib-23")
set(CMAKE_LINKER "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/clang-manylinux/ld.lld")
set(CMAKE_LINKER_LINK "")
set(CMAKE_LINKER_LLD "")
set(CMAKE_CXX_COMPILER_LINKER "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/bin/ld.lld")
set(CMAKE_CXX_COMPILER_LINKER_ARCHITECTURE_FLAGS "")
set(CMAKE_CXX_COMPILER_LINKER_ID "")
set(CMAKE_CXX_COMPILER_LINKER_VERSION "")
set(CMAKE_CXX_COMPILER_LINKER_FRONTEND_VARIANT "")
set(CMAKE_MT "")
set(CMAKE_TAPI "CMAKE_TAPI-NOTFOUND")
set(CMAKE_COMPILER_IS_GNUCXX )
set(CMAKE_CXX_COMPILER_LOADED 1)
set(CMAKE_CXX_COMPILER_WORKS TRUE)
set(CMAKE_CXX_ABI_COMPILED TRUE)

set(CMAKE_CXX_COMPILER_ENV_VAR "CXX")

set(CMAKE_CXX_COMPILER_ID_RUN 1)
set(CMAKE_CXX_SOURCE_FILE_EXTENSIONS C;M;c++;cc;cpp;cxx;m;mm;mpp;CPP;ixx;cppm;ccm;cxxm;c++m)
set(CMAKE_CXX_IGNORE_EXTENSIONS inl;h;hpp;HPP;H;o;O;obj;OBJ;def;DEF;rc;RC)

foreach (lang IN ITEMS C OBJC OBJCXX)
  if (CMAKE_${lang}_COMPILER_ID_RUN)
    foreach(extension IN LISTS CMAKE_${lang}_SOURCE_FILE_EXTENSIONS)
      list(REMOVE_ITEM CMAKE_CXX_SOURCE_FILE_EXTENSIONS ${extension})
    endforeach()
  endif()
endforeach()

set(CMAKE_CXX_LINKER_PREFERENCE 30)
set(CMAKE_CXX_LINKER_PREFERENCE_PROPAGATES 1)
set(CMAKE_CXX_LINKER_DEPFILE_SUPPORTED )
set(CMAKE_LINKER_PUSHPOP_STATE_SUPPORTED TRUE)
set(CMAKE_CXX_LINKER_PUSHPOP_STATE_SUPPORTED TRUE)

# Save compiler ABI information.
set(CMAKE_CXX_SIZEOF_DATA_PTR "8")
set(CMAKE_CXX_COMPILER_ABI "ELF")
set(CMAKE_CXX_BYTE_ORDER "LITTLE_ENDIAN")
set(CMAKE_CXX_LIBRARY_ARCHITECTURE "aarch64-unknown-linux-gnu")

if(CMAKE_CXX_SIZEOF_DATA_PTR)
  set(CMAKE_SIZEOF_VOID_P "${CMAKE_CXX_SIZEOF_DATA_PTR}")
endif()

if(CMAKE_CXX_COMPILER_ABI)
  set(CMAKE_INTERNAL_PLATFORM_ABI "${CMAKE_CXX_COMPILER_ABI}")
endif()

if(CMAKE_CXX_LIBRARY_ARCHITECTURE)
  set(CMAKE_LIBRARY_ARCHITECTURE "aarch64-unknown-linux-gnu")
endif()

set(CMAKE_CXX_CL_SHOWINCLUDES_PREFIX "")
if(CMAKE_CXX_CL_SHOWINCLUDES_PREFIX)
  set(CMAKE_CL_SHOWINCLUDES_PREFIX "${CMAKE_CXX_CL_SHOWINCLUDES_PREFIX}")
endif()





set(CMAKE_CXX_IMPLICIT_INCLUDE_DIRECTORIES "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/opt/rh/gcc-toolset-14/root/usr/include/c++/14;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/opt/rh/gcc-toolset-14/root/usr/include/c++/14/aarch64-redhat-linux;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/opt/rh/gcc-toolset-14/root/usr/include/c++/14/backward;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/lib/clang/23/include;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/include/aarch64-unknown-linux-gnu;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/usr/local/include;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/usr/include")
set(CMAKE_CXX_IMPLICIT_LINK_LIBRARIES "stdc++;m;gcc_s;gcc;c;gcc_s;gcc")
set(CMAKE_CXX_IMPLICIT_LINK_DIRECTORIES "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/lib/aarch64-unknown-linux-gnu;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/lib/clang/23/lib/aarch64-unknown-linux-gnu;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/opt/rh/gcc-toolset-14/root/usr/lib/gcc/aarch64-redhat-linux/14;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/opt/rh/gcc-toolset-14/root/usr/lib64;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/lib64;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/usr/lib64;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/lib;/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/manylinux-sysroot/usr/lib")
set(CMAKE_CXX_IMPLICIT_LINK_FRAMEWORK_DIRECTORIES "")
set(CMAKE_CXX_COMPILER_CLANG_RESOURCE_DIR "/home/nvidia/.codex/worktrees/optimized-core-release/build/linux-optimization/toolchains/llvm-23/lib/clang/23")

set(CMAKE_CXX_COMPILER_IMPORT_STD "")
set(CMAKE_CXX_COMPILER_IMPORT_STD_ERROR_MESSAGE  "Experimental `import std` support not enabled when detecting toolchain; it must be set before `CXX` is enabled (usually a `project()` call)")
set(CMAKE_CXX_STDLIB_MODULES_JSON "")
