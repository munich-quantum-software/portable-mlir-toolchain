from pathlib import Path
import hashlib, json, subprocess
sdk=Path(__file__).resolve().parents[2]
core=Path('/home/nvidia/.codex/worktrees/linux-optimization-experiments')
root=Path(__file__).resolve().parent
records=root/'measurements';records.mkdir()
venvs=root/'venvs';venvs.mkdir()
benchmark=hashlib.sha256((core/'test/release/benchmark_optimization.py').read_bytes()).hexdigest()
variants=[]
for path in sorted((root/'downloads').rglob('artifacts.json')):
 manifest=json.loads(path.read_text());requirements=path.with_name('requirements.txt')
 assert manifest['benchmark_sha256']==benchmark
 assert hashlib.sha256(requirements.read_bytes()).hexdigest()==manifest['requirements_sha256']
 for artifact in manifest['artifacts']:
  name='clang22-native-'+manifest['pgo']+'-'+artifact['name'];variants.append(name)
  wheel=path.parent/'artifacts'/artifact['name']/Path(artifact['wheel']).name
  assert hashlib.sha256(wheel.read_bytes()).hexdigest()==artifact['wheel_sha256']
  python=venvs/name/'bin/python'
  subprocess.run(['uv','venv','--python','3.14.7',str(python.parent.parent)],check=True)
  subprocess.run(['uv','pip','sync','--python',str(python),str(requirements)],check=True)
  subprocess.run(['uv','pip','install','--no-deps','--python',str(python),str(wheel)],check=True)
  (records/(name+'-inputs.json')).write_text(json.dumps(manifest,indent=2))
  (records/(name+'-size.json')).write_text(json.dumps(artifact|{'wheel':str(wheel),'benchmark_sha256':benchmark},indent=2))
old=core/'build/linux-optimization'
for name in ['M-PGO-native-clang-bench-both-bolt','M-PGO-native-gcc-bench-both-bolt']:
 variants.append(name)
 (venvs/name).symlink_to(old/'venvs'/name,target_is_directory=True)
 for suffix in ['inputs','size']:
  (records/f'{name}-{suffix}.json').symlink_to(old/'measurements'/f'{name}-{suffix}.json')
(root/'variants.json').write_text(json.dumps(variants,indent=2))
for cohort in [1,2]:
 cohort_root=root/f'cohort-{cohort}';cohort_root.mkdir()
 for name in ['venvs','measurements']:(cohort_root/name).symlink_to(root/name,target_is_directory=True)
print('Prepared',variants)
